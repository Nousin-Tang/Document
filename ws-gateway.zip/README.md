# 调用连接

客户端WS => gateway => ws-server服务  --MQ--> ws-ser-server服务（处理消息）

> ws-server重启，会关闭所有websocket连接，并触发close事件，ws-ser-server服务也会收到关闭连接的MQ通知

# 客户端地址
gateway static目录下的 index.html
请求连接：http://localhost:8080/api/index.html
> 可以使用客户端向服务端发送消息

# 向客户端发送消息
GET方式-请求地址：http://localhost:8080/api/order/test/send?type=3&uid=0&content=some_msg


