package com.nousin.ws;

import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;
import javax.websocket.CloseReason;
import javax.websocket.EncodeException;
import javax.websocket.Session;

import cn.hutool.json.JSONUtil;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class WebSocketUtil {

    public static String sessionUid(Session session) {
        return session.getId();
    }

    /**
     * 记录当前在线连接数
     */
    public static final AtomicInteger onlineCount = new AtomicInteger(0);

    /**
     * 存放所有在线的客户端
     */
    public static final Map<String, WebSocketServer> clients = new ConcurrentHashMap<>();

    /**
     * 处理客户请求
     *
     * @param message 消息内容
     */
    public static void handleEvent(Msg message, Session session) throws IOException, EncodeException {
        int event = message.getType();
        String secret = message.getSecret();
        String content = message.getContent();
        log.info("【websocket】LoginId:{},LoginName:{}", secret, content);
        if (event != 0) {
            if (secret == null || content == null) {
                message.setContent("editUserId 和 editUserName 不能为空");
                sendMessageToOne(session, message);
                return;
            }
        } else {
            secret = "001";
            content = "heartbeat";
        }

        switch (event) {
            case 1:
                log.info("WebSocket 心跳检测");
                RabbitSendUtil.sendHeartBeatMsg(WebSocketUtil.sessionUid(session));
                sendMessageToOne(session, message);
                break;
            case 2:
                log.info("WebSocket发送消息");
                RabbitSendUtil.sendCommonMsg(WebSocketUtil.sessionUid(session), JSONUtil.toJsonStr(message));
                sendMessageToOne(session, message);
                break;
            default:
                log.info("TeamworkEditEvent事件类型:{} 不存在！", event);
        }
    }

    /**
     * 群发消息
     *
     * @param message 消息内容
     */
    public static void sendMessageTo(Msg message, List<WebSocketServer> list) {
        for (WebSocketServer s : list) {
            sendMessageToOne(s.getSession(), message);
        }
        log.info("服务端给客户端群发发送消息{}", message.toString());
    }

    /**
     * 对特定客户端发送消息
     *
     * @param toSession WebSocket 对象
     * @param message   消息内容
     */
    public static void sendMessageToOne(Session toSession, Msg message) {
        log.info("服务端给指定客户端【{}】 发送消息{}", toSession.getId(), message.toString());
        synchronized (toSession) {
            try {
                toSession.getBasicRemote().sendObject(message);
            } catch (IOException e) {
                e.printStackTrace();
            } catch (EncodeException e) {
                e.printStackTrace();
            }
        }
    }

    public static void closeSession(Session session, Msg message) {
        clients.remove(sessionUid(session));
        try {
            if (message == null)
                session.close();
            else
                session.close(new CloseReason(CloseReason.CloseCodes.NORMAL_CLOSURE, JSONUtil.toJsonStr(message)));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static Session getSession(String uid) {
        final WebSocketServer socketServer = clients.get(uid);
        if (socketServer == null) {
            return null;
        }
        return socketServer.getSession();
    }
}
