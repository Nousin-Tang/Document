package com.nousin.ws;


import java.io.IOException;
import javax.websocket.EncodeException;
import javax.websocket.OnClose;
import javax.websocket.OnError;
import javax.websocket.OnMessage;
import javax.websocket.OnOpen;
import javax.websocket.Session;
import javax.websocket.server.ServerEndpoint;

import cn.hutool.core.util.StrUtil;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import static com.nousin.ws.WebSocketUtil.clients;
import static com.nousin.ws.WebSocketUtil.onlineCount;

@Slf4j
@ServerEndpoint(value = "/websocket/server",
        encoders = WebSocketEncoder.class,
        decoders = WebSocketDecoder.class,
        subprotocols = {"sec-webSocket-protocol"})
@Component
public class WebSocketServer {

    @Getter
    private Session session;

    @OnOpen
    public void onOpen(Session session) throws IOException, EncodeException {
        onlineCount.incrementAndGet();
        this.session = session;
        final String sessionUid = WebSocketUtil.sessionUid(session);
        clients.put(sessionUid, this);
        log.info("有新连接加入：{}，当前在线人数为：{}", sessionUid, onlineCount.get());
        // 发送消息
        RabbitSendUtil.sendOpenMsg(WebSocketUtil.sessionUid(session));
    }

    @OnClose
    public void onClose(Session session) {
        final String sessionUid = WebSocketUtil.sessionUid(session);
        onlineCount.decrementAndGet();
        clients.remove(sessionUid);
        log.info("有一连接关闭：{}，当前在线人数为：{}", sessionUid, onlineCount.get());
        RabbitSendUtil.sendCloseMsg(WebSocketUtil.sessionUid(session));
    }

    @OnError
    public void onError(Session session, Throwable error) {
        log.error("发生错误：{0}", error);
        RabbitSendUtil.sendErrorMsg(WebSocketUtil.sessionUid(session), error.getCause().toString());
    }

    @OnMessage
    public void onMessage(Msg message, Session session) throws IOException, EncodeException {
        final String sessionUid = WebSocketUtil.sessionUid(session);
        if (StrUtil.isEmpty(sessionUid)) {
            return;
        }
        int event = message.getType();
        if (event == 0) {
            log.info("teamworkEditEvent 为空！");
            return;
        }
        log.info("处理客户端【{}】发送的消息:{}", sessionUid, message.toString());
        WebSocketUtil.handleEvent(message, session);
    }
}