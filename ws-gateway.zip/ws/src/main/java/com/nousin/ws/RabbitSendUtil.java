package com.nousin.ws;

import java.nio.charset.StandardCharsets;

import cn.hutool.json.JSONUtil;
import org.springframework.amqp.core.MessageProperties;
import org.springframework.amqp.rabbit.core.RabbitTemplate;


public class RabbitSendUtil {

    public static void send(String message) {
        ApplicationContextUtil.getBean(RabbitTemplate.class)
                .send(RabbitMQConfig.TOPIC_EXCHANGE, RabbitMQConfig.WS_KEY,
                        new org.springframework.amqp.core.Message(message.getBytes(StandardCharsets.UTF_8), new MessageProperties()));
    }

    public static void sendOpenMsg(String uid) {
        send(JSONUtil.toJsonStr(Msg.builder().type(MsgType.OPEN.getType()).uid(uid).content("连接打开通知").build()));
    }

    public static void sendCloseMsg(String uid) {
        send(JSONUtil.toJsonStr(Msg.builder().type(MsgType.CLOSE.getType()).uid(uid).content("连接关闭通知").build()));
    }

    public static void sendHeartBeatMsg(String uid) {
        send(JSONUtil.toJsonStr(Msg.builder().type(MsgType.HEART_BEAT.getType()).uid(uid).content("心跳通知").build()));
    }

    public static void sendErrorMsg(String uid, String errorMsg) {
        send(JSONUtil.toJsonStr(Msg.builder().type(MsgType.ERROR.getType()).uid(uid).content(errorMsg).build()));
    }

    public static void sendCommonMsg(String uid, String content) {
        send(JSONUtil.toJsonStr(Msg.builder().type(MsgType.COMMON.getType()).uid(uid).content(content).build()));
    }
}
