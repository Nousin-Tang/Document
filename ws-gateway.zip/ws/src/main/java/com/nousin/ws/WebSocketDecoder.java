package com.nousin.ws;

import javax.websocket.DecodeException;
import javax.websocket.Decoder;
import javax.websocket.EndpointConfig;

import cn.hutool.json.JSONUtil;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class WebSocketDecoder implements Decoder.Text<Msg> {

    @Override
    public Msg decode(String jsonMessage) throws DecodeException {
        return JSONUtil.toBean(jsonMessage, Msg.class);
    }

    @Override
    public boolean willDecode(String jsonMessage) {
        return JSONUtil.isJson(jsonMessage);
    }

    @Override
    public void init(EndpointConfig endpointConfig) {

    }

    @Override
    public void destroy() {

    }
}