package com.nousin.ws;

import javax.websocket.Session;

import cn.hutool.json.JSONUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.stereotype.Component;

@Slf4j
@Component
public class MyRabbitListener {

    @RabbitListener(queues = RabbitMQConfig.QUEUE_WS_SERVER)
    public void myListener(String message) {
        if (JSONUtil.isJson(message)) {
            final Msg msg = JSONUtil.toBean(message, Msg.class);
            final Session session = WebSocketUtil.getSession(msg.getUid());
            if (session == null) {
                log.warn("客户端不存在【{}】", msg.getUid());
            } else {
                if (msg.getType() == MsgType.CLOSE.getType()) {
                    WebSocketUtil.closeSession(session, msg);
                } else if (msg.getType() == MsgType.COMMON.getType()) {
                    WebSocketUtil.sendMessageToOne(session, msg);
                }
            }

        }
        System.out.println("消费者接受消息： " + message);
    }
}