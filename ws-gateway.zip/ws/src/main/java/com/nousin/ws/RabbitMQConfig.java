package com.nousin.ws;

import org.springframework.amqp.core.Binding;
import org.springframework.amqp.core.BindingBuilder;
import org.springframework.amqp.core.Exchange;
import org.springframework.amqp.core.ExchangeBuilder;
import org.springframework.amqp.core.Queue;
import org.springframework.amqp.core.QueueBuilder;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class RabbitMQConfig {
    //交换机名称
    public final static String TOPIC_EXCHANGE = "topic_exchange_ws_server";
    //队列名称
    public final static String QUEUE_WS = "queue_ws";

    public final static String WS_KEY = "ws.msg";

     public final static String QUEUE_WS_SERVER = "queue_ws_server";

     public final static String WS_SERVER_KEY = "ws-server.msg";

    //声明交换机
    @Bean("topicExchange")
    public Exchange getTopicEXchange() {
        return ExchangeBuilder.topicExchange(TOPIC_EXCHANGE).durable(true).build();
    }

    //声明队列
    @Bean("queueName")
    public Queue getQueueName() {
        return QueueBuilder.durable(QUEUE_WS).build();
    }

    //绑定队列道交换机
    @Bean
    public Binding queueExchange(@Qualifier("queueName") Queue queue, @Qualifier("topicExchange") Exchange exchange) {
        return BindingBuilder.bind(queue).to(exchange).with(WS_KEY).noargs();
    }

}