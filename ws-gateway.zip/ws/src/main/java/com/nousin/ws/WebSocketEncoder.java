package com.nousin.ws;

import javax.websocket.EncodeException;
import javax.websocket.Encoder;
import javax.websocket.EndpointConfig;

import cn.hutool.json.JSONUtil;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class WebSocketEncoder implements Encoder.Text<Msg> {
    @Override
    public String encode(Msg msg) throws EncodeException {
        try {
            return JSONUtil.toJsonStr(msg);
        } catch (Exception e) {
            e.printStackTrace();
            log.info("服务端数据转换json结构失败！");
            return "";
        }
    }

    @Override
    public void init(EndpointConfig endpointConfig) {

    }

    @Override
    public void destroy() {

    }
}