package com.nousin.ws;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Msg {
    /**
     * 0-心跳，1-连接通知，2-关闭通知，3-正常发送消息，4-错误消息
     */
    private int type;

    /**
     * 每个 WebSocket 连接的唯一ID
     */
    private String uid;

    /**
     * 消息内容
     */
    private String content;

    private String secret;
}
