package com.nousin.ws;

import lombok.Getter;


public enum MsgType {
    HEART_BEAT(0, "心跳"),
    OPEN(1, "连接通知"),
    CLOSE(2, "关闭通知"),
    COMMON(3, "正常发送消息"),
    ERROR(4, "错误消息"),
    ;
    @Getter
    private int type;
    @Getter
    private String name;

    MsgType(int index, String desc) {
        this.type = index;
        this.name = desc;
    }
}
