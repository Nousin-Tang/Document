package com.nousin.ws;

import java.io.IOException;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cn.hutool.core.util.StrUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

/**
 * websocket请求头中可以包含Sec-WebSocket-Protocol这个属性，该属性是一个自定义的子协议。
 * 它从客户端发送到服务器并返回从服务器到客户端确认子协议。我们可以利用这个属性添加token。
 * <p>
 * var token='jlllwei68jj776'
 * var  ws = new WebSocket("ws://" + url+ "/webSocketServer",[token]);
 * <p>
 * <p>
 * 拿到token可以解析判断，set到response里面，否则Gateway源码WebSocketClientHandShaker会报异常，因为response没拿到子协议。
 * <p>
 * 建议前端使用原生websocket API请求
 */
@Slf4j
@Order(1)
@Component
@WebFilter(filterName = "WebSocketFilter", urlPatterns = "/websocket/server")
public class WebSocketFilter implements Filter {

    @Override
    public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain)
            throws IOException, ServletException {
        HttpServletResponse response = (HttpServletResponse) servletResponse;
        final HttpServletRequest request = (HttpServletRequest) servletRequest;
        final String requestURI = request.getRequestURI();
        String token = request.getHeader("Sec-WebSocket-Protocol");
        log.info("【WebSocketFilter】response.setHeader = key:{},value:{}", "Sec-WebSocket-Protocol", token);
        // 校验token
        if (StrUtil.isNotBlank(token))
            response.setHeader("Sec-WebSocket-Protocol", token);
        else if (StrUtil.equals("/query", requestURI)||StrUtil.equals("/write", requestURI)){}
        else
            throw new RuntimeException(String.format("websocket请求 %s 没有携带token，无法请求！", requestURI));
        filterChain.doFilter(servletRequest, servletResponse);
    }
}