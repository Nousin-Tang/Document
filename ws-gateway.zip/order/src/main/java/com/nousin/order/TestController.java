package com.nousin.order;

import java.net.URLEncoder;
import java.util.HashMap;

import cn.hutool.core.map.MapUtil;
import cn.hutool.core.util.ObjectUtil;
import cn.hutool.json.JSONUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@Slf4j
@RestController
@RequestMapping("test")
public class TestController {

    @Autowired
    RestTemplate restTemplate;

    @GetMapping("/send")
    public String send(Msg message) {
        final ResponseEntity<String> forEntity = restTemplate.getForEntity("http://ws-ser-server/ws-receiver" +
                        "?type=" + message.getType() + "&uid=" + message.getUid() + "&content=" + URLEncoder.encode(message.getContent())
                , String.class);
        final String body = forEntity.getBody();
        log.info(body);
        return "OK";
    }

}
