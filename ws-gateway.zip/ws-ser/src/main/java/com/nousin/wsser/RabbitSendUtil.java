package com.nousin.wsser;

import java.nio.charset.StandardCharsets;

import cn.hutool.json.JSONUtil;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.core.MessageProperties;
import org.springframework.amqp.rabbit.core.RabbitTemplate;


public class RabbitSendUtil {

    public static void send(String message) {
        ApplicationContextUtil.getBean(RabbitTemplate.class)
                .send(RabbitMQConfig.TOPIC_EXCHANGE, RabbitMQConfig.WS_SERVER_KEY,
                        new Message(message.getBytes(StandardCharsets.UTF_8), new MessageProperties()));
    }

    public static void sendCloseMsg(String uid) {
        send(JSONUtil.toJsonStr(Msg.builder().type(MsgType.CLOSE.getType()).uid(uid).content("连接关闭通知").build()));
    }

    public static void sendErrorMsg(String uid, String errorMsg) {
        send(JSONUtil.toJsonStr(Msg.builder().type(MsgType.ERROR.getType()).uid(uid).content(errorMsg).build()));
    }

    public static void sendCommonMsg(String uid, String content) {
        send(JSONUtil.toJsonStr(Msg.builder().type(MsgType.COMMON.getType()).uid(uid).content(content).build()));
    }
    public static void sendMsg(Msg msg) {
        send(JSONUtil.toJsonStr(msg));
    }
}
