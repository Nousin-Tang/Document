package com.nousin.wsser;

import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.stereotype.Component;

@Component
public class MyRabbitListener {

    @RabbitListener(queues = RabbitMQConfig.QUEUE_WS)
    public void myListener(String message) {
        // 处理 WebSocket 消息
        System.out.println("接受到 WebSocket 消息： " + message);
    }
}